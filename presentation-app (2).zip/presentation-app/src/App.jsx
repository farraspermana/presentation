import React, { useState, useEffect } from 'react';
import {
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  TrendingUp,
  Users,
  Activity,
  Target,
  Brain,
  Zap,
  Lock,
  BarChart3,
  Award,
  Moon,
  Sun
} from 'lucide-react';

// --- Data & Content ---

const slides = [
  {
    id: 'title',
    title: "Strategic Collaboration Proposal",
    subtitle: "Optimizing User Allocations & Incentive Integrity",
    tagline: "Protecting Your Airdrop from Sybil Attacks",
    content: "A data-driven approach to rewarding quality engagement while filtering out sybil activity.",
    theme: "hero"
  },
  {
    id: 'impact',
    title: "Our Track Record",
    theme: "impact",
    mainNumber: "$4.2M",
    mainLabel: "Protected Across 6 Protocols",
    description: "We've identified and filtered sybil attacks, ensuring rewards reach real users",
    items: [
      { value: "89%", label: "Detection Rate" },
      { value: "6", label: "Protocols Secured" },
      { value: "24K", label: "Sybils Filtered" }
    ]
  },
  {
    id: 'vision',
    title: "Partnership Model",
    subtitle: "Quality Over Quantity",
    icon: <Target size={48} color="#3b5998" strokeWidth={1.5} />,
    points: [
      "Automate manual analysis and reporting",
      "Provide actionable allocation intelligence",
      "Ensure rewards reach genuine users, not bots",
      "Adjust formulas weekly based on your goals"
    ]
  },
  {
    id: 'formula-intro',
    title: "The Core Formula",
    subtitle: "A Dynamic Approach to Scoring",
    theme: "formula",
    content: "We propose a dual-factor scoring system that balances Performance (w_i) with Integrity (α_i).",
  },
  {
    id: 'simulator',
    title: "Impact Simulator",
    subtitle: "See the Honesty Multiplier in Action",
    theme: "simulator",
    content: "Adjust the sliders to see how integrity affects the final payout."
  },
  {
    id: 'weight',
    title: "Factor 1: Base Weight (wi)",
    subtitle: "Performance & Compliance",
    icon: <Activity size={48} color="#3b5998" strokeWidth={1.5} />,
    description: "wi = f(x₁, x₂, ..., xₙ). This score reflects the user's compliance with target indicators. Flexible and adaptable weekly.",
    metrics: [
      { text: "Trading Activity", priority: "high" },
      { text: "Capital Flow Patterns", priority: "high" },
      { text: "Portfolio Diversity", priority: "high" },
      { text: "Platform Engagement", priority: "high" },
      { text: "User Consistency", priority: "high" },
      { text: "Network Contribution", priority: "high" }
    ]
  },
  {
    id: 'alpha',
    title: "Factor 2: The Honesty Multiplier (αi)",
    subtitle: "Quality Assurance & Sybil Resistance",
    icon: <ShieldCheck size={48} color="#64748b" strokeWidth={1.5} />,
    description: "αi = (1 - penalty). This parameter is recalculated weekly to actively reward genuine community members and penalize sybils.",
    sections: [
      {
        title: "Wallet behavior analysis with +800 parametrs",
        icon: <Lock size={20} />,
        text: ""
      },
      {
        title: "Trading patterns and execution quality",
        icon: <TrendingUp size={20} />,
        text: ""
      },
      {
        title: "Community participation and influence scoring",
        icon: <Users size={20} />,
        text: ""
      }
    ]
  },
  {
    id: 'commercial',
    title: "Investment & Value",
    subtitle: "Partnership Structure",
    icon: <Award size={48} color="#3b5998" strokeWidth={1.5} />,
    theme: "commercial",
    sections: [
      {
        title: "Setup & Integration",
        subtitle: "Initial data ingestion, 800-parameter model deployment, and alignment with your criteria.",
        amount: "One-time investment"
      },
      {
        title: "Active Protection",
        subtitle: "Weekly monitoring, model updates, detailed reporting, and continuous optimization throughout your program.",
        amount: "Weekly engagement"
      },
      {
        title: "Aligned Success",
        subtitle: "Performance-based allocation in points/tokens, ensuring our success is tied to your program's success.",
        amount: "Token allocation"
      }
    ],
    roi: {
      savings: "30-60%",
      savingsLabel: "Budget Saved",
      quality: "3-5x",
      qualityLabel: "User Quality Improvement"
    }
  },
  {
    id: 'conclusion',
    title: "Let's Protect Your Airdrop",
    subtitle: "Time to Act",
    urgency: "Launch Window: 2-3 Weeks",
    theme: "cta",
    points: [
      "Approve target indicators for Week 1",
      "Deploy 800-parameter detection system",
      "Begin weekly reporting cycles",
      "Review full implementation demo"
    ],
    timeline: [
      { week: "Week 1", task: "Integration & baseline analysis" },
      { week: "Week 2", task: "First sybil detection report" },
      { week: "Week 3", task: "Optimized allocation rollout" }
    ]
  }
];

// --- Components ---

const SlideIndicator = ({ total, current }) => (
  <div className="slide-indicators">
    <div className="slide-counter">
      Slide {current + 1} of {total}
    </div>
    <div className="indicator-dots">
      {Array.from({ length: total }).map((_, idx) => (
        <div
          key={idx}
          className={`indicator ${idx === current ? 'active' : ''}`}
        />
      ))}
    </div>
  </div>
);

const HeroSlide = ({ slide }) => (
  <div className="hero-slide animate-fadeIn">
    <div className="hero-icon">
      <img src="/archer-logo.png" alt="Archer Logo" className="hero-logo" />
    </div>
    <h1 className="hero-title">
      {slide.title}
    </h1>
    <h2 className="hero-subtitle">{slide.subtitle}</h2>
    {slide.tagline && <p className="hero-tagline">{slide.tagline}</p>}
    <p className="hero-content">{slide.content}</p>
  </div>
);

const ProblemSlide = ({ slide }) => (
  <div className="problem-slide animate-fadeIn">
    <h1 className="problem-header">{slide.title}</h1>
    <p style={{ fontSize: '1.25rem', color: '#d1d5db', marginBottom: '16px' }}>{slide.subtitle}</p>
    <p style={{ fontSize: '1.125rem', color: '#9ca3af', lineHeight: '1.7' }}>{slide.description}</p>
    <div className="problem-stats">
      {slide.stats.map((stat, idx) => (
        <div key={idx} className="problem-stat">
          <div className="problem-stat-number">{stat.number}</div>
          <div className="problem-stat-label">{stat.label}</div>
        </div>
      ))}
    </div>
  </div>
);

const ImpactSlide = ({ slide }) => (
  <div className="impact-slide animate-fadeIn">
    <div className="impact-number">{slide.mainNumber}</div>
    <div className="impact-label">{slide.mainLabel}</div>
    <p className="impact-description">{slide.description}</p>
    <div className="impact-grid">
      {slide.items.map((item, idx) => (
        <div key={idx} className="impact-item">
          <div className="impact-item-value">{item.value}</div>
          <div className="impact-item-label">{item.label}</div>
        </div>
      ))}
    </div>
  </div>
);

const ListSlide = ({ slide }) => (
  <div className="list-slide animate-fadeIn">
    <div className="slide-header">
      {slide.icon}
      <div>
        <h2 className="slide-title">{slide.title}</h2>
        <p className="slide-subtitle">{slide.subtitle}</p>
      </div>
    </div>
    
    <div className="points-grid">
      {slide.points.map((point, idx) => (
        <div key={idx} className="point-item">
          <div className="point-icon">
            <Zap size={16} strokeWidth={1.5} />
          </div>
          <p className="point-text">{point}</p>
        </div>
      ))}
    </div>
  </div>
);

const FormulaSlide = ({ slide }) => (
  <div className="formula-slide animate-fadeIn">
    <h2 className="formula-title">{slide.title}</h2>
    <p className="formula-subtitle">{slide.content}</p>

    <div className="formula-box">
      <div className="formula-terms">
        
        <div className="formula-term">
          <span className="term-label">Base Weight</span>
          <div className="term-value">w<span style={{fontSize: '1.25rem', verticalAlign: 'sub'}}>i</span></div>
          <div className="term-divider"></div>
          <div className="term-description">Performance Indicators</div>
        </div>

        <div className="formula-operator">×</div>

        <div className="formula-term purple">
          <span className="term-label purple">Honesty Multiplier</span>
          <div className="term-value">α<span style={{fontSize: '1.25rem', verticalAlign: 'sub'}}>i</span></div>
          <div className="term-divider"></div>
          <div className="term-description">1 - Penalty</div>
        </div>

        <div className="formula-operator">×</div>

        <div className="formula-term blue">
          <span className="term-label blue">Total Pool</span>
          <div className="term-value">P<span style={{fontSize: '1.25rem', verticalAlign: 'sub'}}>total</span></div>
          <div className="term-divider"></div>
          <div className="term-description">1.2M - (Ref + Vault)</div>
        </div>

      </div>
    </div>
  </div>
);

// Helper functions for simulator calculations
const TOTAL_USERS = 16000;
const BASE_WEIGHT = 1000;
const TOTAL_POOL = BASE_WEIGHT * TOTAL_USERS; // Total points to distribute

const calculateMetrics = (sybilShare, penaltyMultiplier) => {
  const sybilUsersCount = Math.round(sybilShare * TOTAL_USERS);
  const realUsersCount = TOTAL_USERS - sybilUsersCount;
  
  // Penalty reduces sybil weight: effective weight = (1 - penalty)
  const sybilEffectiveMultiplier = 1 - penaltyMultiplier;
  
  // Total tokens taken away from sybils due to penalty
  const sybilBaseAllocation = sybilUsersCount * BASE_WEIGHT;
  const sybilActualAllocation = sybilUsersCount * BASE_WEIGHT * sybilEffectiveMultiplier;
  const tokensTakenFromSybils = sybilBaseAllocation - sybilActualAllocation;
  
  // These tokens are redistributed to real users
  const realUsersBaseAllocation = realUsersCount * BASE_WEIGHT;
  const redistributedToReal = tokensTakenFromSybils;
  const totalForRealUsers = realUsersBaseAllocation + redistributedToReal;
  
  // Allocation per real user
  const allocationPerRealUser = totalForRealUsers / realUsersCount;
  const allocationPerSybilUser = BASE_WEIGHT * sybilEffectiveMultiplier;
  
  // Calculate budget shares
  const shareOfBudgetToReal = (totalForRealUsers / TOTAL_POOL) * 100;
  const shareOfBudgetToSybil = (sybilActualAllocation / TOTAL_POOL) * 100;
  
  // Percent vs baseline
  const realUserRewardPercent = (allocationPerRealUser / BASE_WEIGHT) * 100;
  
  return {
    realUsersCount,
    sybilUsersCount,
    allocationPerRealUser,
    allocationPerSybilUser,
    realUserRewardPercent,
    shareOfBudgetToReal,
    shareOfBudgetToSybil,
    effectiveMultiplier: sybilEffectiveMultiplier,
    tokensTakenFromSybils
  };
};

const generateChartData = (penaltyMultiplier) => {
  const scenarios = [
    { share: 0, label: '0%' },
    { share: 0.1, label: '10%' },
    { share: 0.2, label: '20%' },
    { share: 0.3, label: '30%' },
    { share: 0.4, label: '40%' },
    { share: 0.5, label: '50%' },
    { share: 0.6, label: '60%' }
  ];
  
  return scenarios.map(scenario => {
    const metrics = calculateMetrics(scenario.share, penaltyMultiplier);
    return {
      sybilSharePercent: scenario.share * 100,
      label: scenario.label,
      allocationPoints: metrics.allocationPerRealUser,
      deviation: metrics.allocationPerRealUser - BASE_WEIGHT
    };
  });
};

const SimulatorSlide = ({ slide }) => {
  const [penalty, setPenalty] = useState(0.75);
  const [sybilShare, setSybilShare] = useState(0.2);
  
  const metrics = calculateMetrics(sybilShare, penalty);
  const chartData = generateChartData(penalty);
  
  const getRewardColor = (percent) => {
    if (percent >= 80) return '#3b5998';
    if (percent >= 50) return '#b8860b';
    return '#991b1b';
  };

  return (
    <div className="simulator-slide-new animate-fadeIn">
      <div className="sim-header">
        <div className="sim-header-top">
          <div className="sim-title-group">
            <ShieldCheck size={28} color="#3b5998" strokeWidth={1.5} />
            <div>
              <h2 className="sim-title">Impact Simulator</h2>
              <p className="sim-subtitle">
                Illustrative view of how sybil filtering and penalty strength affect rewards for real users.
              </p>
            </div>
          </div>
          <div className="sim-badge">
            <BarChart3 size={14} strokeWidth={1.5} />
            <span>Scenario-based · Not actual Extended data</span>
          </div>
        </div>
      </div>

      <div className="sim-content-grid">
        {/* Left side - Controls and Metrics */}
        <div className="sim-left-panel">
          <div className="sim-controls-section">
            <div className="sim-slider-group">
              <label className="sim-label">Sybil Penalty (p)</label>
              <div className="sim-slider-value">-{penalty.toFixed(2)}</div>
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.05" 
                value={penalty}
                onChange={(e) => setPenalty(parseFloat(e.target.value))}
                className="sim-slider"
              />
              <div className="sim-slider-caption">
                0 = sybils get full weight, 1 = sybils get nothing
              </div>
            </div>

            <div className="sim-slider-group">
              <label className="sim-label">Share of users flagged as sybil</label>
              <div className="sim-slider-value">
                {(sybilShare * 100).toFixed(0)}% · {metrics.sybilUsersCount.toLocaleString()} of 16,000
              </div>
              <input 
                type="range" 
                min="0" 
                max="0.6" 
                step="0.01" 
                value={sybilShare}
                onChange={(e) => setSybilShare(parseFloat(e.target.value))}
                className="sim-slider"
              />
              <div className="sim-slider-caption">
                Scenario parameter for illustration only
              </div>
            </div>
          </div>

          <div className="sim-metrics-panel">
            <div className="sim-metric-row">
              <span className="sim-metric-label">Base Weight (wi):</span>
              <span className="sim-metric-value">{BASE_WEIGHT} pts</span>
            </div>
            <div className="sim-metric-row">
              <span className="sim-metric-label">Penalty (p):</span>
              <span className="sim-metric-value" style={{ color: '#ef4444' }}>-{penalty.toFixed(2)}</span>
            </div>
            <div className="sim-metric-row full-width">
              <span className="sim-metric-label">Multiplier (αi):</span>
              <span className="sim-metric-value" style={{ color: '#a78bfa' }}>
                {metrics.effectiveMultiplier.toFixed(2)}x
              </span>
            </div>
            <div className="sim-divider"></div>
            <div className="sim-metric-row">
              <span className="sim-metric-label">Real users:</span>
              <span className="sim-metric-value">{metrics.realUsersCount.toLocaleString()}</span>
            </div>
            <div className="sim-metric-row">
              <span className="sim-metric-label">Sybil-like users:</span>
              <span className="sim-metric-value">{metrics.sybilUsersCount.toLocaleString()}</span>
            </div>
            <div className="sim-divider"></div>
            <div className="sim-metric-row highlight full-width">
              <span className="sim-metric-label">Allocation per real user:</span>
              <span className="sim-metric-value" style={{ color: getRewardColor(metrics.realUserRewardPercent) }}>
                {Math.round(metrics.allocationPerRealUser)} pts
              </span>
            </div>
            <div className="sim-metric-row full-width">
              <span className="sim-metric-label">Allocation per sybil:</span>
              <span className="sim-metric-value">
                {Math.round(metrics.allocationPerSybilUser)} pts
              </span>
            </div>
            <div className="sim-divider"></div>
            <div className="sim-metric-row">
              <span className="sim-metric-label">Budget to real users:</span>
              <span className="sim-metric-value">{metrics.shareOfBudgetToReal.toFixed(1)}%</span>
            </div>
            <div className="sim-metric-row">
              <span className="sim-metric-label">Budget to sybils:</span>
              <span className="sim-metric-value">{metrics.shareOfBudgetToSybil.toFixed(1)}%</span>
            </div>
          </div>
        </div>

        {/* Right side - Single Dynamic Bar */}
        <div className="sim-visual-container">
          <div className="sim-visual-header">
            <span className="sim-visual-title">Real User Allocation</span>
            <span className="sim-visual-subtitle">Current scenario</span>
          </div>
          <div className="sim-visual-content">
            <div className="sim-visual-bar-wrapper">
              {/* Scale markers */}
              <div className="sim-scale">
                {[2750, 2500, 2250, 2000, 1750, 1500, 1250, 1000, 750, 500, 250, 0].map(val => (
                  <div key={val} className="sim-scale-mark">
                    <span className="sim-scale-value">{val}</span>
                    <div className="sim-scale-line"></div>
                  </div>
                ))}
              </div>
              
              {/* Main bar */}
              <div className="sim-bar-container">
                <div className="sim-bar-track">
                  {/* Animated bar */}
                  <div 
                    className="sim-bar blue"
                    style={{ height: `${Math.min((metrics.allocationPerRealUser / 2750) * 100, 100)}%` }}
                  >
                    <div className="sim-bar-glow"></div>
                  </div>
                  
                  {/* Value display */}
                  <div
                    className="sim-bar-value"
                    style={{ bottom: `${Math.min((metrics.allocationPerRealUser / 2750) * 100, 100)}%` }}
                  >
                    <div className="sim-value-deviation" style={{
                      color: metrics.allocationPerRealUser >= 1000 ? '#3b5998' : '#991b1b'
                    }}>
                      {metrics.allocationPerRealUser >= 1000 ? '+' : ''}
                      {Math.round(metrics.allocationPerRealUser - BASE_WEIGHT)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="sim-visual-note">
              {Math.round(metrics.tokensTakenFromSybils).toLocaleString()} pts taken from sybils, 
              redistributed to {metrics.realUsersCount.toLocaleString()} real users
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricSlide = ({ slide }) => {
  const getPriorityBadge = (priority) => {
    if (priority === 'high') return 'KEY';
    if (priority === 'medium') return 'MED';
    return null;
  };

  return (
    <div className="list-slide animate-fadeIn">
      <div className="slide-header">
        {slide.icon}
        <div>
          <h2 className="slide-title">{slide.title}</h2>
          <p className="slide-subtitle subtitle-green">{slide.subtitle}</p>
        </div>
      </div>

      <div className="description-box">
        {slide.description}
      </div>

      <div className="metrics-grid custom-scrollbar">
        {slide.metrics.map((metric, idx) => (
          <div key={idx} className="metric-item">
            <BarChart3 size={20} className="metric-icon" strokeWidth={1.5} />
            <span className="metric-text">{metric.text}</span>
            {getPriorityBadge(metric.priority) && (
              <span className="metric-badge">{getPriorityBadge(metric.priority)}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const DetailSlide = ({ slide }) => (
  <div className="list-slide animate-fadeIn">
    <div className="slide-header">
      {slide.icon}
      <div>
        <h2 className="slide-title">{slide.title}</h2>
        <p className="slide-subtitle subtitle-purple">{slide.subtitle}</p>
      </div>
    </div>

    <div className="description-box purple">
      {slide.description}
    </div>

    <div className="sections-grid">
      {slide.sections.map((section, idx) => (
        <div key={idx} className="section-item">
          <div className="section-header">
            {section.icon}
            <h3 className="section-title">{section.title}</h3>
          </div>
          {section.text && <p className="section-text">{section.text}</p>}
        </div>
      ))}
    </div>
  </div>
);

const CommercialSlide = ({ slide }) => (
  <div className="list-slide animate-fadeIn">
    <div className="slide-header">
      {slide.icon}
      <div>
        <h2 className="slide-title">{slide.title}</h2>
        <p className="slide-subtitle">{slide.subtitle}</p>
      </div>
    </div>

    <div className="commercial-grid">
      {slide.sections.map((section, idx) => (
        <div key={idx} className="commercial-card">
          <div className="commercial-card-header">
            <div className="commercial-number">{idx + 1}</div>
            <h3 className="commercial-card-title">{section.title}</h3>
          </div>
          <p className="commercial-card-text">{section.subtitle}</p>
          <div className="commercial-amount">{section.amount}</div>
        </div>
      ))}
    </div>

    {slide.roi && (
      <div className="commercial-value">
        <div className="commercial-value-header">Expected Value Delivered</div>
        <div className="commercial-roi">
          <div className="commercial-roi-item">
            <div className="commercial-roi-value">{slide.roi.savings}</div>
            <div className="commercial-roi-label">{slide.roi.savingsLabel}</div>
          </div>
          <div className="commercial-roi-item">
            <div className="commercial-roi-value">{slide.roi.quality}</div>
            <div className="commercial-roi-label">{slide.roi.qualityLabel}</div>
          </div>
        </div>
      </div>
    )}
  </div>
);

const CTASlide = ({ slide }) => (
  <div className="cta-slide animate-fadeIn">
    <div className="cta-header">
      {slide.urgency && <p className="cta-urgency">{slide.urgency}</p>}
      <h2 className="cta-title">{slide.title}</h2>
      <p className="cta-subtitle">{slide.subtitle}</p>
    </div>

    <div className="cta-content">
      <div className="cta-box">
        <h3 className="cta-box-title">Implementation Roadmap</h3>
        <ul className="cta-list">
          {slide.points.map((point, idx) => (
            <li key={idx} className="cta-item">
              <span className="cta-text">{point}</span>
            </li>
          ))}
        </ul>
      </div>

      {slide.timeline && (
        <div className="cta-timeline">
          <div className="cta-timeline-header">Launch Timeline</div>
          {slide.timeline.map((item, idx) => (
            <div key={idx} className="cta-timeline-item">
              <span className="cta-timeline-week">{item.week}</span>
              <span>{item.task}</span>
            </div>
          ))}
        </div>
      )}
    </div>

    <div className="cta-footer">
      <button className="cta-button">
        Start Protecting Your Airdrop
      </button>
    </div>
  </div>
);


// --- Main App ---

export default function PresentationDeck() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Initialize from localStorage or default to light mode
    const saved = localStorage.getItem('theme');
    return saved === 'dark';
  });

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) setCurrentSlide(prev => prev + 1);
  };

  const prevSlide = () => {
    if (currentSlide > 0) setCurrentSlide(prev => prev - 1);
  };

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev);
  };

  // Apply theme to document
  useEffect(() => {
    const theme = isDarkMode ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [isDarkMode]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowRight') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  const renderSlide = () => {
    const slide = slides[currentSlide];
    if (slide.theme === 'hero') return <HeroSlide slide={slide} />;
    if (slide.theme === 'problem') return <ProblemSlide slide={slide} />;
    if (slide.theme === 'impact') return <ImpactSlide slide={slide} />;
    if (slide.theme === 'formula') return <FormulaSlide slide={slide} />;
    if (slide.theme === 'simulator') return <SimulatorSlide slide={slide} />;
    if (slide.theme === 'commercial') return <CommercialSlide slide={slide} />;
    if (slide.theme === 'cta') return <CTASlide slide={slide} />;
    if (slide.id === 'vision') return <ListSlide slide={slide} />;
    if (slide.id === 'weight') return <MetricSlide slide={slide} />;
    if (slide.id === 'alpha') return <DetailSlide slide={slide} />;
    return <HeroSlide slide={slide} />;
  };

  return (
    <div className="presentation-container">
      <div className="presentation-deck">

        <div className="top-bar">
          <div className="top-bar-left">CONFIDENTIAL // DRAFT</div>
          <div className="top-bar-right">
            <div className="top-bar-title">PROPOSAL.DECK</div>
            <button
              onClick={toggleTheme}
              className="theme-toggle"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>
        </div>

        <div className="slide-content">
          {renderSlide()}
        </div>

        <div className="nav-bar">
          
          <button 
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="nav-button"
          >
            <ChevronLeft size={20} strokeWidth={1.5} />
            <span>Previous</span>
          </button>

          <div className="nav-center">
            <span className="nav-title">
              {slides[currentSlide].title}
            </span>
            <SlideIndicator total={slides.length} current={currentSlide} />
          </div>

          <button 
            onClick={nextSlide}
            disabled={currentSlide === slides.length - 1}
            className="nav-button next"
          >
            <span>Next</span>
            <ChevronRight size={20} strokeWidth={1.5} />
          </button>
        </div>

      </div>
    </div>
  );
}
